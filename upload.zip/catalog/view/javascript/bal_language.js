if(get_cookie('language') == 'ru-ru'){
	var text_show_next = 'Показать еще {show} {items}',
	    text_show_all = 'Показано {show} {items} из {shows}',
	    text_loading = 'Загрузка...',
	    text_no_more_show = 'Больше нечего показывать',
	    text_d1_items = 'товар',
	    text_d2_items = 'товара',
	    text_d3_items = 'товаров';
} else {
	var text_show_next = 'Показати ще {show} {items}',
	    text_show_all = 'Показано {show} {items} из {shows}',
	    text_loading = 'Завантаження...',
	    text_no_more_show = 'Більше нічого показувати',
	    text_d1_items = 'товар',
	    text_d2_items = 'товари',
	    text_d3_items = 'товарів';
}